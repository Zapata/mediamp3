Balabolka, version 2.7.0.549
Copyright (c) 2006-2013 Ilya Morozov
All Rights Reserved

WWW: http://www.cross-plus-a.com/balabolka.htm
E-mail: crossa@hotbox.ru

Licence: Freeware
Operating System: Microsoft Windows XP/Vista/7/8
Speech API: 4.0/5.0 and above
Microsoft Speech Platform


*** Portable Version ***

    Portable Balabolka does not require an installation and can be
    run from a USB drive. A computer must have at least one voice
    installed.



*** Text To Speech Engines ***

    Balabolka uses a Text-To-Speech (TTS) engine to read text files.
    If you do not currently have a TTS engine, you can download one
    for free from Microsoft web-site:

    http://www.microsoft.com/msagent/downloads/user.aspx

    If you have a TTS installed you will see a list of available
    voices in the main window of Balabolka.

    The program supports both SAPI 4 and SAPI 5 Text-To-Speech
    Engines. SAPI 4 is an older technology, so I recommend the using
    of SAPI 5.

    To use SAPI 4 you need to install spchapi.exe:

    http://download.microsoft.com/download/speechSDK/Install/4.0a/WIN98/EN-US/spchapi.EXE

    If you are interested in some higher quality voices, please see
    the help file of Balabolka.



*** Microsoft Speech Platform ***

    The Microsoft Speech Platform consists of a Runtime and Runtime Languages
    (engines for speech recognition and text-to-speech). There are separate Runtime
    Languages for speech recognition and speech synthesis.

    http://msdn.microsoft.com/en-us/library/hh361572.aspx

    Use the following steps to install the Microsoft Speech Platform:

   1 Uninstall any previous version of the Speech Platform Runtime from your computer.
   2 Determine whether you are using a 32-bit or 64-bit operating system.
   3 Download and install the Speech Platform Runtime that matches your operating system.
   4 Download and install Runtime Languages for use with the Speech Platform.



*** Donation ***

    If you want to help Balabolka - buy my program Cross+A:

    http://www.cross-plus-a.com

    As long as people pay money for Cross+A, Balabolka will remain freeware.

    Thank you!  

###